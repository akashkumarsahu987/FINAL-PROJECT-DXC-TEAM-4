import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalsearchComponent } from './localsearch.component';

describe('LocalsearchComponent', () => {
  let component: LocalsearchComponent;
  let fixture: ComponentFixture<LocalsearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LocalsearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalsearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
