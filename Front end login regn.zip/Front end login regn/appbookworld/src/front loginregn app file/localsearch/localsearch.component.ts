import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-localsearch',
  templateUrl: './localsearch.component.html',
  styleUrls: ['./localsearch.component.css']
})
export class LocalsearchComponent implements OnInit {

  book:Book[];
  title:string;
  

  constructor(private bookService:BookService) { }
  
  ngOnInit(): void {
    this.title = null;
  }

  private searchCustomers() {
    this.bookService.displayLocalBooks(this.title)
      .subscribe(book => this.book = book);
  }
  onSubmit() {
    this.searchCustomers();
  }
}
