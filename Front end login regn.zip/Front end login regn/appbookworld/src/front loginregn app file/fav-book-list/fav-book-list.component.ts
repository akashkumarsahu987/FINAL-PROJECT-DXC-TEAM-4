import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fav-book-list',
  templateUrl: './fav-book-list.component.html',
  styleUrls: ['./fav-book-list.component.css']
})
export class FavBookListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
