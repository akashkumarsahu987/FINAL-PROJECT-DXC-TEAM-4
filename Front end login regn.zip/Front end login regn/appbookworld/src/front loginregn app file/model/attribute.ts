export class Attribute {
}
export class VolumeInfo{
    title:string;
    authors:string[];
    publisher:string;
    publishedDate: string;
    description:string;
    industryIdentifiers:string[];
    readingModes:string;
    pageCount:number;
    printType:string;
    categories:string[];
    averageRating:number;
    ratingsCount:number;
    maturityRating:string;
    allowAnonLogging:boolean;
    contentVersion:string;
    panelizationSummary:string;
    imageLinks:ImageLinks;
    language:string;
    previewLink:string;
    infoLink:string;
    canonicalVolumeLink:string;
}
export class ImageLinks{
    smallThumbnail:string;
    thumbnail:string;
}