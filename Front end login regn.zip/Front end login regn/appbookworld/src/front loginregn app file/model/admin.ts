export class Admin {
    id:number;
    emailId:string;
    userName:string;
    password:string;
    sCode:string;
    authdata?: string;
}
