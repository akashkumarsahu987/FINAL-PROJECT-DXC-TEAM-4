export class Book {

id:number;
title:string;
author:string;
category:String
description:string;
isbn:string;
language:string;
authdata?: string;

}
