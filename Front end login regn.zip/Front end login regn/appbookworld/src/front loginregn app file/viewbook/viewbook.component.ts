import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-viewbook',
  templateUrl: './viewbook.component.html',
  styleUrls: ['./viewbook.component.css']
})
export class ViewbookComponent implements OnInit {
  book:Book[]=[];
  isUpdate=false;
  updateBk:Book=new Book();
  msg:string;
  errorMsg:string;
  

  
    constructor(private bookService:BookService ) { }
  
    ngOnInit(): void {
      console.log("Am inside view component");
      this.bookService.getAllBooks().subscribe(data=>this.book=data);
    
    }
    public viewUpdateBook(book:Book){
      this.isUpdate=true;
      this.updateBk=book;
    }
    public updateBook(){
      console.log("Update Book :"+ JSON.stringify(this.updateBk));
  
      this.bookService.updateBook(this.updateBk).subscribe(  (data)=>{
        console.log("Data",data);
        this.msg=data;
        this.errorMsg=undefined;
            },
        (error)=>{
          this.errorMsg=error.error;
        console.log(this.errorMsg);
        this.msg=undefined;
              }
        );
       
        // get the latest data after update
        this.bookService.getAllBooks().subscribe(data=>this.book=data);
        this.isUpdate=false;
    }
  
  public deleteBook(id:number)  {
  console.log("Delete Book id :"+ id);
  this.bookService.deleteBook(id).subscribe(  (data)=>{
    console.log("Data",data);
    this.msg=data;
    this.errorMsg=undefined;
        },
    (error)=>{
      this.errorMsg=error.error;
    console.log(this.errorMsg);
    this.msg=undefined;
          }
    );
}
}
