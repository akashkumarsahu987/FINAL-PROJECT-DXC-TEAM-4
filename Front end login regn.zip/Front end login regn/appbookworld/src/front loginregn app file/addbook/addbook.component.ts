import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {
  book:Book=new Book();
  msg:string;
  errorMsg:string;

  constructor(private bookService:BookService) { }

  ngOnInit(): void {
  }
  addBook(){
    console.log("Add new book.");
    console.log(this.book);
    this.bookService.addBook(this.book).subscribe(
      (data)=>{
      console.log("Data",data);
      this.msg=data;
      this.errorMsg=undefined;
          },
      (error)=>{
        this.errorMsg=error.error;
      console.log(this.errorMsg);
      this.msg=undefined;
            }
      );
  }

}
