import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from './model/book';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http:HttpClient) { }

  public displayBooks(bookname:string):Observable<any>{
    return this.http.get("https://www.googleapis.com/books/v1/volumes?q="+bookname);
  }

  public displayCategoryBooks(categoryname:string):Observable<any>{
    return this.http.get("https://www.googleapis.com/books/v1/volumes?q=subject:"+categoryname);
  }
  public addBook(book:Book):Observable<any>{
    return this.http.post("http://localhost:8102/api/mongo/book/add",book,{responseType:'text'});
  }
  public getAllBooks():Observable<any>{
    return this.http.get("http://localhost:8102/api/mongo/book/getall");
  }
  public updateBook(updateBk:Book):Observable<any>{
      return this.http.put("http://localhost:8102/api/mongo/book/update/"+updateBk.id,updateBk,{responseType:'text'});
    }
    public deleteBook(id:Number):Observable<any>{
      return this.http.delete("http://localhost:8102/api/mongo/book/delete/"+id,{responseType:'text'});
    }
    public displayLocalBooks(title:string):Observable<any>{
      return this.http.get("http://localhost:8102/api/mongo/book/getbyTitle/"+title);
    }
    public getAllUsers():Observable<any> {
      return this.http.get("http://localhost:8090/getall");
     }

}
