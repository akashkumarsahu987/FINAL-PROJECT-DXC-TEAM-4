import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../model/admin';
import { RegistrationService } from '../service/registration.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  admin:Admin=new Admin();
  msg:string;
  errorMsg:string;
  userData: any;
 myData:any;
  // view :boolean=true;
  
  constructor(private regService:RegistrationService,private router:Router) { }
  ngOnInit(): void {

    
  }
 
  loginAdmin(){
    console.log("Add new Employee.");
    console.log(this.admin);
    this.regService.loginAdmin(this.admin).subscribe(
      (data)=>{
        
      console.log("Data",data);
      this.msg=data;
      this.errorMsg=undefined;
     
      this.router.navigate(['admindashboard'])
      
          },
      (error)=>{
        this.errorMsg=error.error;
      console.log(this.errorMsg);
      this.msg=undefined;
            }
      );
      // this.view=false;
  }
}