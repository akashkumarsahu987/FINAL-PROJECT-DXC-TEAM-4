import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { VolumeInfo } from '../model/attribute';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  volinfo:VolumeInfo[]=[];
  show:boolean=false;
  constructor(private bookService:BookService) { }
  
  ngOnInit(): void {
  }

  public dispbooks(name:string){
    console.log("inside dispbooks");
    this.bookService.displayBooks(name).subscribe(data=>{
      console.log(data.items.length);
      
      for(let i in data.items)
      {
        let item=data.items[i];
        
        this.volinfo.push(item.volumeInfo);
        console.log("Volume info"+i);
        console.log(this.volinfo);
        
      }
       
    });
    
    this.show=true;
    
  }

}
