import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import {AuthService as AuthGuard} from './service/auth.service';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { FavBookListComponent } from './fav-book-list/fav-book-list.component';
import { HomeComponent } from './home/home.component';
import { CategoriesComponent } from './categories/categories.component';
import { ContactComponent } from './contact/contact.component';
import { SearchComponent } from './search/search.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { BookstoreComponent } from './bookstore/bookstore.component';
import { ViewbookComponent } from './viewbook/viewbook.component';
import { AddbookComponent } from './addbook/addbook.component';
import { HelloComponent } from './hello/hello.component';
import { UsersComponent } from './users/users.component';
import { LocalsearchComponent } from './localsearch/localsearch.component';


const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'search',component:SearchComponent},
  {path:'login',component:LoginComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'dashboard',component:DashBoardComponent,canActivate:[AuthGuard]},
  {path:'edit',component:EditProfileComponent},
  {path:'fav',component:FavBookListComponent},
  {path:'categories', component: CategoriesComponent},
  {path:'cotact', component: ContactComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'admindashboard',component:AdmindashboardComponent},
  {path:'bookstore',component:BookstoreComponent},
  {path:'viewbook',component:ViewbookComponent},
  {path:'addbook',component:AddbookComponent},

  {path:'hello',component:HelloComponent},
  {path:'users',component:UsersComponent},
  {path:'localsearch',component:LocalsearchComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes),CommonModule],
  // imports: [RouterModule.forRoot(routes,{onSameUrlNavigation:'reload'}), CommonModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
