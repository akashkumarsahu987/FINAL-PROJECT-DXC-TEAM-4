import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book.service';
import { RegistrationService } from '../service/registration.service';

@Component({
  selector: 'app-bookstore',
  templateUrl: './bookstore.component.html',
  styleUrls: ['./bookstore.component.css']
})
export class BookstoreComponent implements OnInit {

  constructor(private router:Router,private regService:RegistrationService,bookService:BookService) { }

  ngOnInit(): void {
  }

}
