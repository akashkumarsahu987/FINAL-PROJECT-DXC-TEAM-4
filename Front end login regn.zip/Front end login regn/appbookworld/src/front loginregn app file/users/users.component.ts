import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { User } from '../model/user';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  user:User[]=[];
  constructor(private bookService:BookService ) { }

  ngOnInit(): void {
    console.log("Am inside view component");
    this.bookService.getAllUsers().subscribe(data=>this.user=data);
  }

}
