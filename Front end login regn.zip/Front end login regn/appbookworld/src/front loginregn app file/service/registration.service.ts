import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Admin } from '../model/admin';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  currentUser: any;
  currentUserSubject: any;

  constructor(private http:HttpClient)  { this.currentUserSubject = new BehaviorSubject(JSON.parse(localStorage.getItem('currentUser')));
  this.currentUser = this.currentUserSubject.asObservable(); }
  public get currentUserValue(): User {
    return this.currentUserSubject.value;
}
  loginUser(user: User):Observable<any> {
    console.log("am inside loginUser");
    //console.log(user.userName);
    return this.http.post("http://localhost:8090/login",user,{responseType:'text'})
    .pipe(map(userlogin => {
      // store user details and basic auth credentials in local storage to keep user logged in between page refreshes
      user.authdata = window.btoa(user.emailId+':'+user.password);
      localStorage.setItem('currentUser', JSON.stringify(userlogin));
      this.currentUserSubject.next(userlogin);
      return userlogin;
  }));

   }
   regUser(user: User):Observable<any> {
    console.log("am inside regUser");
    return this.http.post("http://localhost:8090/registeruser",user,{responseType:'text'});
   }
   public updateUser(updateUser:User):Observable<any>{
    return this.http.put("http://localhost:8086/update/"+updateUser.emailId,updateUser,{responseType:'text'});
  }
  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
}
loginAdmin(admin: Admin):Observable<any> {
  console.log("am inside regAdmin");
  return this.http.post("http://localhost:8091/login",admin,{responseType:'text'});
 }
}
